package com.library.repository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    private List<String> books = new ArrayList<>();

    // Repository methods
    public void save(String book) {
        books.add(book);
        System.out.println("Book saved: " + book);
    }

    public void delete(String book) {
        books.remove(book);
        System.out.println("Book removed: " + book);
    }

    public void findAll() {
        System.out.println("Books in repository: " + books);
    }
}