package com.library.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    // Pointcut to match all methods in the service package
    @Pointcut("execution(* com.library.service.*.*(..))")
    private void selectAllMethods() {}

    // Advice method for logging before method execution
    @Before("selectAllMethods()")
    public void beforeAdvice() {
        System.out.println("Going to setup student profile.");
    }

    // Advice method for logging after method execution
    @After("selectAllMethods()")
    public void afterAdvice() {
        System.out.println("Student profile has been setup.");
    }
}
