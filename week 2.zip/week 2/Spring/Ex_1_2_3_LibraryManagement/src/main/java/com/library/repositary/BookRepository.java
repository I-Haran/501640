package com.library.repositary;

import java.util.ArrayList;
import java.util.List;

public class BookRepository {
    private List<String> books = new ArrayList<>();

    public void save(String book) {
        books.add(book);
        System.out.println("Book saved: " + book);
    }

    public void delete(String book) {
        books.remove(book);
        System.out.println("Book removed: " + book);
    }

    public void findAll() {
        System.out.println("Books in repository: " + books);
    }
}
